export type Product = {
  id: string;
  name: string;
  category: string;
  purity: string;
  weightGrams: number;
  imageUrl: string | null;
  availability: "In Stock" | "Made to Order" | "Sold";
};

/**
 * PLACEHOLDER: none of your uploaded documents contain a real product
 * catalog (SKUs, actual prices, real photos) — only one mock example in
 * an earlier spec draft, which I'm not treating as real inventory.
 *
 * Wire this to your actual source (a database table, or a CMS like
 * Sanity/Contentful) and return real records. Until then this returns an
 * empty list so the gallery page shows an honest "no products yet" state
 * rather than fabricated jewelry.
 */
export async function getProducts(): Promise<Product[]> {
  return [];
}

export async function getCategories(): Promise<string[]> {
  const products = await getProducts();
  return Array.from(new Set(products.map((p) => p.category)));
}
