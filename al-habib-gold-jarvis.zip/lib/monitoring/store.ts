import { randomUUID } from "crypto";
import type { CheckResult } from "./checks";

/**
 * PLACEHOLDER STORAGE — same caveat as audit-log.ts: in-memory, resets on
 * restart, doesn't share across serverless instances. Replace with a real
 * table (or at minimum a persistent KV store) before relying on this for
 * historical monitoring data.
 */
export type MonitorRun = {
  id: string;
  timestamp: string;
  results: CheckResult[];
  hasIssues: boolean;
};

const MAX_RUNS_KEPT = 500;
const runs: MonitorRun[] = [];

export function recordMonitorRun(results: CheckResult[]): MonitorRun {
  const run: MonitorRun = {
    id: randomUUID(),
    timestamp: new Date().toISOString(),
    results,
    hasIssues: results.some((r) => r.status === "error" || r.status === "warning"),
  };
  runs.push(run);
  if (runs.length > MAX_RUNS_KEPT) runs.shift();
  return run;
}

export function getRecentRuns(limit = 20): MonitorRun[] {
  return runs.slice(-limit).reverse();
}

export function getLatestRun(): MonitorRun | null {
  return runs.length ? runs[runs.length - 1] : null;
}

/**
 * PLACEHOLDER — no real alert channel is configured yet (no email/SMS/
 * WhatsApp Business API credentials were provided in your documents).
 * This currently just logs server-side. Before this is a real "alert me"
 * system, wire one of:
 *   - Email: Resend, SendGrid, or Postmark (needs an API key + verified sender)
 *   - WhatsApp: WhatsApp Business API or a provider like Twilio (needs approval + credentials)
 *   - Simple/free option: a webhook into a Slack/Discord channel you own
 * Each just needs one fetch() call added where marked below.
 */
export async function dispatchAlert(run: MonitorRun) {
  const issues = run.results.filter((r) => r.status === "error" || r.status === "warning");
  if (issues.length === 0) return;

  console.warn(
    `[MONITOR ALERT] ${issues.length} issue(s) detected at ${run.timestamp}:`,
    issues.map((i) => `${i.check}: ${i.message}`).join(" | ")
  );

  // TODO: send a real notification here, e.g.:
  // await fetch(process.env.ALERT_WEBHOOK_URL!, {
  //   method: "POST",
  //   headers: { "Content-Type": "application/json" },
  //   body: JSON.stringify({ text: `Al Habib Gold monitor: ${issues.length} issue(s) found` }),
  // });
}
