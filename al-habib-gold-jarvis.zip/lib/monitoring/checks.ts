import { getAuditLog } from "@/lib/audit-log";
import { getLiveRates } from "@/lib/ai/public-assistant-prompt";

/**
 * PLACEHOLDER: fill in the real pages/endpoints on your live site once
 * it's deployed. Without a live URL yet, this list is empty and the
 * uptime/broken-link checks below will simply report "nothing configured"
 * rather than fabricating a passing result.
 */
export const MONITORED_URLS: string[] = [
  // "https://alhabibgold.com/",
  // "https://alhabibgold.com/products",
  // "https://alhabibgold.com/about",
];

export type CheckResult = {
  check: string;
  status: "ok" | "warning" | "error" | "not_configured";
  message: string;
  detail?: Record<string, unknown>;
};

async function checkUrl(url: string): Promise<CheckResult> {
  try {
    const start = Date.now();
    const res = await fetch(url, { method: "GET", redirect: "follow" });
    const durationMs = Date.now() - start;

    if (!res.ok) {
      return {
        check: "uptime_and_links",
        status: "error",
        message: `${url} returned HTTP ${res.status}`,
        detail: { url, statusCode: res.status },
      };
    }
    if (durationMs > 3000) {
      return {
        check: "uptime_and_links",
        status: "warning",
        message: `${url} responded slowly (${durationMs}ms)`,
        detail: { url, durationMs },
      };
    }
    return {
      check: "uptime_and_links",
      status: "ok",
      message: `${url} is healthy (${durationMs}ms)`,
      detail: { url, durationMs },
    };
  } catch (err) {
    return {
      check: "uptime_and_links",
      status: "error",
      message: `${url} failed to respond: ${err instanceof Error ? err.message : "unknown error"}`,
      detail: { url },
    };
  }
}

export async function runUptimeAndLinkChecks(): Promise<CheckResult[]> {
  if (MONITORED_URLS.length === 0) {
    return [
      {
        check: "uptime_and_links",
        status: "not_configured",
        message: "No URLs configured yet — add your live page URLs to MONITORED_URLS in lib/monitoring/checks.ts.",
      },
    ];
  }
  return Promise.all(MONITORED_URLS.map(checkUrl));
}

/**
 * Pricing sync check: flags if the live rate feed hasn't been verified
 * recently. Currently getLiveRates() is still a placeholder (see
 * public-assistant-prompt.ts), so this will always report "not_configured"
 * until that's wired to a real feed — intentional, not a bug.
 */
export async function runPricingSyncCheck(): Promise<CheckResult> {
  const rates = await getLiveRates();
  if (!rates.lastVerified) {
    return {
      check: "pricing_sync",
      status: "not_configured",
      message: "No live rate feed connected yet — getLiveRates() is still a placeholder.",
    };
  }

  const ageMs = Date.now() - new Date(rates.lastVerified).getTime();
  const STALE_THRESHOLD_MS = 15 * 60 * 1000; // 15 minutes

  if (ageMs > STALE_THRESHOLD_MS) {
    return {
      check: "pricing_sync",
      status: "error",
      message: `Rate data is stale (last verified ${Math.round(ageMs / 60000)} minutes ago).`,
      detail: { lastVerified: rates.lastVerified },
    };
  }
  return {
    check: "pricing_sync",
    status: "ok",
    message: "Rate data is current.",
    detail: { lastVerified: rates.lastVerified },
  };
}

/**
 * Security anomaly check: looks at REAL audit log data (login attempts)
 * rather than fabricated numbers. Flags repeated failed logins in a short
 * window as a possible brute-force attempt.
 */
export function runSecurityAnomalyCheck(): CheckResult {
  const entries = getAuditLog();
  const now = Date.now();
  const WINDOW_MS = 15 * 60 * 1000;

  const recentFailures = entries.filter(
    (e) => e.action === "login_failed" && now - new Date(e.timestamp).getTime() < WINDOW_MS
  );

  if (recentFailures.length >= 5) {
    return {
      check: "security_anomaly",
      status: "error",
      message: `${recentFailures.length} failed admin login attempts in the last 15 minutes.`,
      detail: { count: recentFailures.length },
    };
  }
  if (recentFailures.length > 0) {
    return {
      check: "security_anomaly",
      status: "warning",
      message: `${recentFailures.length} failed admin login attempt(s) in the last 15 minutes.`,
      detail: { count: recentFailures.length },
    };
  }
  return {
    check: "security_anomaly",
    status: "ok",
    message: "No suspicious login activity detected.",
  };
}

export async function runAllChecks(): Promise<CheckResult[]> {
  const [uptimeResults, pricingResult] = await Promise.all([
    runUptimeAndLinkChecks(),
    runPricingSyncCheck(),
  ]);
  const securityResult = runSecurityAnomalyCheck();
  return [...uptimeResults, pricingResult, securityResult];
}
