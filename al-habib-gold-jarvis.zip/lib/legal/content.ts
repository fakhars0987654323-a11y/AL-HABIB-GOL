/**
 * REAL content below (fraud notice, security policy) is taken verbatim from
 * your own uploaded document — it's your business's own written notice, not
 * generated legal advice.
 *
 * Terms & Conditions, Privacy Policy, Refund Policy, Shipping Policy, and
 * Cookie Policy are NOT in any of your documents. I'm not going to write
 * full binding legal terms and present them as ready to publish — that's a
 * lawyer's job, and getting gold/jewellery commerce terms wrong (returns,
 * liability, cross-border UK/Pakistan sales) has real legal and financial
 * consequences for you. Below are section headings only, structured so a
 * lawyer (or you) can fill them in, with a clear on-page notice that they're
 * pending review.
 */

export const FRAUD_NOTICE = `For your safety, please verify every call, message, WhatsApp chat, or social media contact claiming to represent Al Habib Gold, our company, our shop, or any member of our family before making any payment or sharing personal information.

Only trust the official contact details published on this website.

If anyone contacts you using our shop name, our personal names, or claims to represent us, always confirm their identity through our official phone numbers or WhatsApp before proceeding.

We will never ask you to send money to an unverified account or deal with unauthorized individuals.

Disclaimer: If you ignore this verification notice and choose to deal with any unauthorized person, local agent, or third party without confirming through our official contact details, Al Habib Gold and its management will not be responsible for any fraud, financial loss, scam, or damages resulting from such transactions.

Your safety is our priority. Please verify first, then proceed with confidence.`;

export const SECURITY_POLICY = `Your security and privacy are our highest priorities.

Unauthorized Activity Warning
Any attempt to hack, crack, bypass security, scrape data, overload the website, upload malicious content, use automated attacks, or interfere with the normal operation of this website is strictly prohibited. Our security systems continuously monitor suspicious activity. Accounts, devices, or IP addresses involved in unauthorized or harmful behavior may be temporarily or permanently restricted to protect our customers and services.

Account Review & Reinstatement
If a legitimate customer is mistakenly restricted, they may contact us through our official contact details to verify their identity. After successful verification, we will review the case and restore access where appropriate.

Data Protection
We protect customer accounts and data using industry-standard security best practices, secure authentication, encryption where appropriate, and proper access controls. Only authorized administrators have access to administrative functions and sensitive customer information.`;

export const LEGAL_PENDING_NOTICE =
  "This page is a structural placeholder. The content has not been written or legally reviewed yet — do not publish this page live until a qualified lawyer has reviewed wording appropriate for your Pakistan/UK cross-border sales.";

export const LEGAL_SECTION_HEADINGS: Record<string, string[]> = {
  "terms-and-conditions": [
    "Acceptance of Terms",
    "Products and Pricing",
    "Orders and Payment",
    "Shipping and Delivery",
    "Returns and Cancellations",
    "Limitation of Liability",
    "Governing Law (Pakistan / UK)",
    "Contact",
  ],
  "privacy-policy": [
    "What Information We Collect",
    "How We Use Your Information",
    "Data Storage and Security",
    "Third-Party Services",
    "Your Rights (including UK GDPR if applicable)",
    "Contact",
  ],
  "refund-policy": [
    "Eligibility for Returns",
    "Gold/Silver Weight-Based Exchange Terms",
    "Timeframes",
    "Process for Requesting a Refund or Exchange",
    "Non-Returnable Items",
    "Contact",
  ],
  "shipping-policy": [
    "Domestic (Pakistan) Shipping",
    "International (UK) Shipping",
    "Insured/Signature-Required Delivery for High-Value Items",
    "Delivery Timeframes",
    "Lost or Damaged Shipments",
  ],
  "cookie-policy": [
    "What Cookies This Site Uses",
    "Essential vs Optional Cookies",
    "How to Control Cookies",
    "Contact",
  ],
};

export const ABOUT_SECTIONS = {
  companyStory: null as string | null, // PLACEHOLDER — your real story goes here
  shopHistory: null as string | null, // PLACEHOLDER
  mission: null as string | null, // PLACEHOLDER
  vision: null as string | null, // PLACEHOLDER
  certifications: [] as string[], // PLACEHOLDER — list your real hallmark/registration certifications
};
