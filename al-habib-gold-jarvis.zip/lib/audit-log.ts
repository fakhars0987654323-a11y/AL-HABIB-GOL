/**
 * PLACEHOLDER STORAGE: this is an in-memory array so Stage 2 is testable
 * without a database. It resets on every server restart/redeploy and does
 * NOT share state across serverless instances.
 *
 * Before going live, replace this with a real table, e.g. Postgres:
 *   CREATE TABLE admin_audit_log (
 *     id SERIAL PRIMARY KEY,
 *     timestamp TIMESTAMPTZ NOT NULL DEFAULT now(),
 *     action TEXT NOT NULL,
 *     details JSONB,
 *     previous_state JSONB,   -- what changed FROM, so rollback is possible
 *     new_state JSONB         -- what changed TO
 *   );
 * The previous_state/new_state pair is what makes "roll back any single
 * change" (from your requirements) actually possible — a log without the
 * prior value can tell you WHAT changed but not how to undo it.
 */

import { randomUUID } from "crypto";

export type AuditLogEntry = {
  id: string;
  timestamp: string;
  action: string;
  details?: Record<string, unknown>;
  previousState?: unknown;
  newState?: unknown;
};

const auditLog: AuditLogEntry[] = [];

export function logAdminAction(entry: Omit<AuditLogEntry, "id" | "timestamp">) {
  const full: AuditLogEntry = {
    id: randomUUID(),
    timestamp: new Date().toISOString(),
    ...entry,
  };
  auditLog.push(full);
  return full;
}

export function getAuditLog(): AuditLogEntry[] {
  return [...auditLog].reverse(); // most recent first
}

export function getAuditEntry(id: string): AuditLogEntry | undefined {
  return auditLog.find((e) => e.id === id);
}
