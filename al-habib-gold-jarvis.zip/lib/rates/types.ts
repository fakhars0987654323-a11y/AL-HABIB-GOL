export type RatePoint = {
  perGram: number | null;
  perTola: number | null;
  per10Gram?: number | null;
  per100Gram?: number | null;
  perKg?: number | null;
};

export type MarketSnapshot = {
  gold: {
    "24K": RatePoint;
    "22K": RatePoint;
    "18K": RatePoint;
  };
  silver: RatePoint;
  previousDay: {
    gold24KPerGram: number | null;
    silverPerGram: number | null;
  };
  lastVerified: string | null;
  marketStatus: "open" | "closed" | "unknown";
  currency: "PKR";
};

export function emptyRatePoint(): RatePoint {
  return { perGram: null, perTola: null, per10Gram: null, per100Gram: null, perKg: null };
}
