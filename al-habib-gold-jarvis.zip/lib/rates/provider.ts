import { MarketSnapshot, emptyRatePoint } from "./types";

/**
 * PLACEHOLDER: no live rate feed is connected yet. Per your own Project
 * Rules doc ("never show an old gold rate as if live — show unavailable
 * instead"), this returns nulls rather than fabricated numbers.
 *
 * To connect a real feed, two commonly used paid/free-tier APIs for
 * PKR gold/silver rates are goldapi.io and metals-api.com — both need an
 * API key and a small wrapper here that:
 *   1. Fetches 24K gold + silver spot price
 *   2. Derives 22K/18K from 24K using standard purity ratios (22K = 24K × 0.9167, 18K = 24K × 0.75)
 *   3. Converts to PKR/tola (1 tola = 11.6638 grams) for the Pakistan display
 *   4. Verifies against a second source before publishing, per your spec's
 *      "cross-check accuracy before publishing" requirement
 * That verification/fallback logic is a real piece of engineering on its
 * own — flagging it here rather than quietly skipping it.
 */
export async function getMarketSnapshot(): Promise<MarketSnapshot> {
  return {
    gold: {
      "24K": emptyRatePoint(),
      "22K": emptyRatePoint(),
      "18K": emptyRatePoint(),
    },
    silver: emptyRatePoint(),
    previousDay: { gold24KPerGram: null, silverPerGram: null },
    lastVerified: null,
    marketStatus: "unknown",
    currency: "PKR",
  };
}
