import { SignJWT, jwtVerify } from "jose";
import bcrypt from "bcryptjs";

/**
 * REQUIRED environment variables (set these in .env.local, never commit them):
 *  - ADMIN_PASSWORD_HASH   bcrypt hash of your admin password. Generate with:
 *                          node -e "console.log(require('bcryptjs').hashSync('yourPassword', 12))"
 *  - SESSION_SECRET        a long random string (32+ bytes), e.g. `openssl rand -base64 32`
 *
 * PLACEHOLDER: 2FA (TOTP) is scaffolded below (verifyTotp) but not wired into
 * the login route yet — real 2FA needs a TOTP secret generated per-admin and
 * a way for you to enroll it (e.g. scan a QR code once). I did not fabricate
 * that enrollment flow since you don't have one yet; flagging it rather than
 * silently shipping "2FA" that doesn't actually check anything.
 */

const SESSION_COOKIE_NAME = "ah_admin_session";
const SESSION_DURATION_SECONDS = 60 * 60 * 8; // 8 hours

function getSessionSecretKey() {
  const secret = process.env.SESSION_SECRET;
  if (!secret || secret.length < 16) {
    throw new Error(
      "SESSION_SECRET is missing or too short. Set a 32+ byte random string in your environment."
    );
  }
  return new TextEncoder().encode(secret);
}

export async function verifyPassword(plainPassword: string): Promise<boolean> {
  const hash = process.env.ADMIN_PASSWORD_HASH;
  if (!hash) {
    throw new Error("ADMIN_PASSWORD_HASH is not set in the environment.");
  }
  return bcrypt.compare(plainPassword, hash);
}

export async function createSessionToken(): Promise<string> {
  return new SignJWT({ role: "admin" })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${SESSION_DURATION_SECONDS}s`)
    .sign(getSessionSecretKey());
}

export async function verifySessionToken(token: string): Promise<boolean> {
  try {
    const { payload } = await jwtVerify(token, getSessionSecretKey());
    return payload.role === "admin";
  } catch {
    return false;
  }
}

export { SESSION_COOKIE_NAME, SESSION_DURATION_SECONDS };

// ---- Login attempt rate limiting ----
// PLACEHOLDER: in-memory, per-instance. Fine for a single-server or dev
// deployment. On Vercel's multi-instance serverless, replace this with a
// shared store (Upstash Redis / Vercel KV) — otherwise an attacker can get
// more attempts than intended by hitting different instances.
const LOGIN_WINDOW_MS = 15 * 60 * 1000; // 15 minutes
const LOGIN_MAX_ATTEMPTS = 5;
const loginAttempts = new Map<string, { count: number; windowStart: number }>();

export function isLoginRateLimited(ip: string): boolean {
  const now = Date.now();
  const entry = loginAttempts.get(ip);
  if (!entry || now - entry.windowStart > LOGIN_WINDOW_MS) {
    loginAttempts.set(ip, { count: 0, windowStart: now });
    return false;
  }
  return entry.count >= LOGIN_MAX_ATTEMPTS;
}

export function recordLoginAttempt(ip: string) {
  const entry = loginAttempts.get(ip);
  if (!entry) {
    loginAttempts.set(ip, { count: 1, windowStart: Date.now() });
    return;
  }
  entry.count += 1;
}

export function clearLoginAttempts(ip: string) {
  loginAttempts.delete(ip);
}

// PLACEHOLDER — real TOTP verification (e.g. via the `otplib` package),
// not yet wired into the login flow. See note at top of file.
export async function verifyTotp(_code: string, _secret: string): Promise<boolean> {
  throw new Error("TOTP verification is not yet implemented — see admin-auth.ts notes.");
}
