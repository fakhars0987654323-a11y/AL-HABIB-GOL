import { LEGAL_PENDING_NOTICE } from "@/lib/legal/content";

export function LegalPlaceholderPage({
  title,
  sections,
}: {
  title: string;
  sections: string[];
}) {
  return (
    <main className="min-h-screen bg-background text-neutral-100 font-sans px-6 py-12">
      <div className="max-w-3xl mx-auto space-y-8">
        <h1 className="font-serif text-3xl">{title}</h1>

        <div className="border border-feedback-warning/40 bg-feedback-warning/10 text-feedback-warning text-sm p-4">
          {LEGAL_PENDING_NOTICE}
        </div>

        <div className="space-y-6">
          {sections.map((heading) => (
            <div key={heading} className="space-y-1 border-b border-neutral-800 pb-4">
              <h2 className="font-serif text-lg text-neutral-200">{heading}</h2>
              <p className="text-sm text-neutral-600">Content pending.</p>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
