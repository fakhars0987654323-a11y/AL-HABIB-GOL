"use client";

import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ArrowUp, ArrowDown, Minus } from "lucide-react";
import type { MarketSnapshot, RatePoint } from "@/lib/rates/types";

function Trend({ current, previous }: { current: number | null; previous: number | null }) {
  if (current === null || previous === null) {
    return <Minus className="w-4 h-4 text-neutral-600" />;
  }
  if (current > previous) return <ArrowUp className="w-4 h-4 text-feedback-success" />;
  if (current < previous) return <ArrowDown className="w-4 h-4 text-feedback-error" />;
  return <Minus className="w-4 h-4 text-neutral-500" />;
}

function RateCard({
  label,
  point,
  previousPerGram,
}: {
  label: string;
  point: RatePoint;
  previousPerGram: number | null;
}) {
  const unavailable = point.perGram === null;

  return (
    <div className="bg-surface border border-neutral-800 p-5 space-y-3">
      <div className="flex justify-between items-center">
        <span className="text-xs uppercase tracking-widest text-gold">{label}</span>
        <Trend current={point.perGram} previous={previousPerGram} />
      </div>
      {unavailable ? (
        <p className="text-sm text-neutral-500">Rate unavailable</p>
      ) : (
        <div className="grid grid-cols-2 gap-2 text-sm text-neutral-200">
          <div>
            <span className="text-neutral-500 text-xs block">Per Gram</span>
            {point.perGram} PKR
          </div>
          <div>
            <span className="text-neutral-500 text-xs block">Per Tola</span>
            {point.perTola} PKR
          </div>
          {point.per10Gram != null && (
            <div>
              <span className="text-neutral-500 text-xs block">10 Gram</span>
              {point.per10Gram} PKR
            </div>
          )}
          {point.per100Gram != null && (
            <div>
              <span className="text-neutral-500 text-xs block">100 Gram</span>
              {point.per100Gram} PKR
            </div>
          )}
          {point.perKg != null && (
            <div>
              <span className="text-neutral-500 text-xs block">1 KG</span>
              {point.perKg} PKR
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export function RateDisplay() {
  const [snapshot, setSnapshot] = useState<MarketSnapshot | null>(null);
  const [loading, setLoading] = useState(true);

  async function load() {
    try {
      const res = await fetch("/api/rates/live");
      const data = await res.json();
      setSnapshot(data);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    const interval = setInterval(load, 60_000);
    return () => clearInterval(interval);
  }, []);

  if (loading || !snapshot) {
    return <div className="text-neutral-500 text-sm">Loading market data…</div>;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-6"
    >
      <div className="flex items-center justify-between">
        <h2 className="font-serif text-2xl text-neutral-100">Live Gold & Silver Market</h2>
        <span
          className={`text-[10px] uppercase tracking-widest px-3 py-1 border ${
            snapshot.marketStatus === "open"
              ? "border-feedback-success text-feedback-success"
              : snapshot.marketStatus === "closed"
              ? "border-neutral-700 text-neutral-500"
              : "border-neutral-800 text-neutral-600"
          }`}
        >
          Market: {snapshot.marketStatus}
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <RateCard label="Gold 24K" point={snapshot.gold["24K"]} previousPerGram={snapshot.previousDay.gold24KPerGram} />
        <RateCard label="Gold 22K" point={snapshot.gold["22K"]} previousPerGram={snapshot.previousDay.gold24KPerGram} />
        <RateCard label="Gold 18K" point={snapshot.gold["18K"]} previousPerGram={snapshot.previousDay.gold24KPerGram} />
        <RateCard label="Silver" point={snapshot.silver} previousPerGram={snapshot.previousDay.silverPerGram} />
      </div>

      <p className="text-xs text-neutral-500">
        {snapshot.lastVerified
          ? `Last verified: ${new Date(snapshot.lastVerified).toLocaleString()}`
          : "No live rate feed connected yet — see lib/rates/provider.ts for setup notes."}
      </p>

      {/* Daily/Weekly/Monthly trend charts intentionally omitted here: charting
          fake data would violate "never invent market data." Once a real
          feed with historical storage exists, a chart (e.g. recharts) can be
          dropped in using that time-series data. */}
      <div className="border border-dashed border-neutral-800 p-6 text-center text-xs text-neutral-600">
        Daily / weekly / monthly trend charts will appear here once historical rate data is being stored.
      </div>
    </motion.div>
  );
}
