"use client";

import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import type { MarketSnapshot } from "@/lib/rates/types";

type Karat = "24K" | "22K" | "18K";

export function RateCalculator() {
  const [snapshot, setSnapshot] = useState<MarketSnapshot | null>(null);
  const [weight, setWeight] = useState<number>(10);
  const [karat, setKarat] = useState<Karat>("22K");
  const [makingCharges, setMakingCharges] = useState<number>(0);
  const [taxPercent, setTaxPercent] = useState<number>(0);
  const [quantity, setQuantity] = useState<number>(1);

  useEffect(() => {
    fetch("/api/rates/live")
      .then((r) => r.json())
      .then(setSnapshot)
      .catch(() => setSnapshot(null));
  }, []);

  const perGram = snapshot?.gold[karat]?.perGram ?? null;
  const rateUnavailable = perGram === null;

  const goldValue = rateUnavailable ? null : perGram! * weight;
  const buyingPricePerUnit = rateUnavailable ? null : goldValue! + makingCharges;
  const totalBeforeTax = rateUnavailable ? null : buyingPricePerUnit! * quantity;
  const taxAmount = rateUnavailable ? null : totalBeforeTax! * (taxPercent / 100);
  const total = rateUnavailable ? null : totalBeforeTax! + taxAmount!;

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      className="bg-surface border border-neutral-800 p-6 space-y-6"
    >
      <h2 className="font-serif text-2xl text-neutral-100">Rate Calculator</h2>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-1">
          <label className="text-xs uppercase tracking-wider text-neutral-400">Weight (grams)</label>
          <input
            type="number"
            min={0}
            value={weight}
            onChange={(e) => setWeight(Number(e.target.value))}
            className="w-full bg-background border border-neutral-800 focus:border-gold px-3 py-2 text-sm text-neutral-100 focus:outline-none"
          />
        </div>
        <div className="space-y-1">
          <label className="text-xs uppercase tracking-wider text-neutral-400">Purity</label>
          <select
            value={karat}
            onChange={(e) => setKarat(e.target.value as Karat)}
            className="w-full bg-background border border-neutral-800 focus:border-gold px-3 py-2 text-sm text-neutral-100 focus:outline-none"
          >
            <option value="24K">24K</option>
            <option value="22K">22K</option>
            <option value="18K">18K</option>
          </select>
        </div>
        <div className="space-y-1">
          <label className="text-xs uppercase tracking-wider text-neutral-400">Making Charges (PKR)</label>
          <input
            type="number"
            min={0}
            value={makingCharges}
            onChange={(e) => setMakingCharges(Number(e.target.value))}
            className="w-full bg-background border border-neutral-800 focus:border-gold px-3 py-2 text-sm text-neutral-100 focus:outline-none"
          />
        </div>
        <div className="space-y-1">
          <label className="text-xs uppercase tracking-wider text-neutral-400">Tax (%)</label>
          <input
            type="number"
            min={0}
            value={taxPercent}
            onChange={(e) => setTaxPercent(Number(e.target.value))}
            className="w-full bg-background border border-neutral-800 focus:border-gold px-3 py-2 text-sm text-neutral-100 focus:outline-none"
          />
        </div>
        <div className="space-y-1 col-span-2">
          <label className="text-xs uppercase tracking-wider text-neutral-400">Quantity</label>
          <input
            type="number"
            min={1}
            value={quantity}
            onChange={(e) => setQuantity(Number(e.target.value))}
            className="w-full bg-background border border-neutral-800 focus:border-gold px-3 py-2 text-sm text-neutral-100 focus:outline-none"
          />
        </div>
      </div>

      <div className="border-t border-neutral-800 pt-4 space-y-2 text-sm">
        {rateUnavailable ? (
          <p className="text-neutral-500">
            Live rate is unavailable, so a price can't be calculated right now — see
            lib/rates/provider.ts to connect a real feed.
          </p>
        ) : (
          <>
            <div className="flex justify-between text-neutral-300">
              <span>Live Gold Value ({karat})</span>
              <span>{goldValue!.toFixed(2)} PKR</span>
            </div>
            <div className="flex justify-between text-neutral-300">
              <span>Buying Price (per unit)</span>
              <span>{buyingPricePerUnit!.toFixed(2)} PKR</span>
            </div>
            <div className="flex justify-between text-neutral-300">
              <span>Tax</span>
              <span>{taxAmount!.toFixed(2)} PKR</span>
            </div>
            <div className="flex justify-between font-medium text-gold border-t border-neutral-800 pt-2">
              <span>Total ({quantity}x)</span>
              <span>{total!.toFixed(2)} PKR</span>
            </div>
            {/* "Selling Price" and "Estimated Profit/Loss" from the spec need
                a cost-basis figure (what the shop paid) that isn't part of a
                customer-facing calculator — that's an admin-side number, not
                something this public tool should expose or guess at. */}
          </>
        )}
      </div>
    </motion.div>
  );
}
