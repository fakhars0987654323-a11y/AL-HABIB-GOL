"use client";

import React, { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Search, Heart, MessageSquare, ImageOff } from "lucide-react";
import type { Product } from "@/lib/products/catalog";
import { BUSINESS_INFO } from "@/lib/ai/public-assistant-prompt";

export function ProductGallery({
  products,
  categories,
}: {
  products: Product[];
  categories: string[];
}) {
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  // Wishlist is local component state only — not persisted per user account
  // yet. Wire this to your real customer-account system (Stage 2+ of that
  // feature) before relying on it surviving a page refresh.
  const [wishlist, setWishlist] = useState<Set<string>>(new Set());

  const filtered = useMemo(() => {
    return products.filter((p) => {
      const matchesQuery = p.name.toLowerCase().includes(query.toLowerCase());
      const matchesCategory = !activeCategory || p.category === activeCategory;
      return matchesQuery && matchesCategory;
    });
  }, [products, query, activeCategory]);

  function toggleWishlist(id: string) {
    setWishlist((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  function whatsappInquiryLink(product: Product) {
    const message = encodeURIComponent(
      `Hello ${BUSINESS_INFO.name}. I'm interested in: ${product.name} (${product.purity}, ${product.weightGrams}g).`
    );
    return `${BUSINESS_INFO.whatsappPakistan}?text=${message}`;
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex items-center flex-1 border border-neutral-800 focus-within:border-gold px-4 py-3 space-x-3">
          <Search className="w-4 h-4 text-neutral-500" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search products…"
            className="flex-1 bg-transparent text-sm text-neutral-100 placeholder-neutral-600 focus:outline-none"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setActiveCategory(null)}
            className={`text-xs uppercase tracking-wider px-4 py-2 border transition-colors ${
              !activeCategory ? "border-gold text-gold" : "border-neutral-800 text-neutral-400"
            }`}
          >
            All
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`text-xs uppercase tracking-wider px-4 py-2 border transition-colors ${
                activeCategory === cat ? "border-gold text-gold" : "border-neutral-800 text-neutral-400"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="border border-dashed border-neutral-800 p-16 text-center space-y-2">
          <ImageOff className="w-8 h-8 text-neutral-700 mx-auto" />
          <p className="text-sm text-neutral-500">
            No products to show yet — connect your real catalog in lib/products/catalog.ts.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((product, i) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: i * 0.05, ease: [0.16, 1, 0.3, 1] }}
              className="bg-surface border border-neutral-800 group"
            >
              <div className="relative aspect-[4/5] bg-background overflow-hidden">
                {product.imageUrl ? (
                  <img
                    src={product.imageUrl}
                    alt={`${product.name}, ${product.purity}`}
                    className="object-cover w-full h-full transition-transform duration-700 group-hover:scale-105"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-neutral-700 text-xs uppercase tracking-widest">
                    No image yet
                  </div>
                )}
                <button
                  onClick={() => toggleWishlist(product.id)}
                  aria-label="Toggle wishlist"
                  className="absolute top-3 right-3 p-2 bg-background/80 border border-neutral-800 hover:border-gold"
                >
                  <Heart
                    className={`w-4 h-4 ${wishlist.has(product.id) ? "fill-gold text-gold" : "text-neutral-300"}`}
                  />
                </button>
              </div>
              <div className="p-4 space-y-2">
                <p className="text-xs uppercase tracking-widest text-gold">{product.category}</p>
                <p className="font-serif text-lg text-neutral-100">{product.name}</p>
                <p className="text-xs text-neutral-500">
                  {product.purity} · {product.weightGrams}g · {product.availability}
                </p>
                <a
                  href={whatsappInquiryLink(product)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center space-x-2 border border-neutral-700 hover:border-gold py-2 text-xs uppercase tracking-wider transition-colors"
                >
                  <MessageSquare className="w-4 h-4 text-gold" />
                  <span>Inquire on WhatsApp</span>
                </a>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
