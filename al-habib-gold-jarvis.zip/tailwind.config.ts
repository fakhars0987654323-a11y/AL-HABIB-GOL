import type { Config } from "tailwindcss";

// This mirrors your existing tailwind.config.ts (from your design system spec)
// with ONE addition: the `feedback` color group, which your tokens.ts spec
// defines but your actual Tailwind config was missing — that's what caused
// `text-feedback-error` to silently render no color at all.
//
// MERGE this into your real config rather than replacing it wholesale if
// you've customized anything else since — the only new block is `feedback`
// under theme.extend.colors.

const config: Config = {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "#0A0A0A", // Deep Black
        surface: "#121212", // Matte Charcoal
        card: "#1A1A1A",
        gold: {
          light: "#DFBD7D",
          DEFAULT: "#C5A059", // Luxury Gold
          dark: "#9E7B38",
        },
        neutral: {
          100: "#F5F5F5",
          200: "#E5E5E5",
          400: "#A3A3A3",
          600: "#525252",
          800: "#262626",
        },
        // ADDED — present in your tokens.ts spec but missing from the
        // actual Tailwind config, which is why feedback-* classes weren't resolving.
        feedback: {
          success: "#4ADE80",
          warning: "#FACC15",
          error: "#F87171",
          info: "#60A5FA",
        },
      },
      fontFamily: {
        sans: ["var(--font-inter)", "sans-serif"],
        serif: ["var(--font-cinzel)", "serif"],
      },
      animation: {
        "fade-in": "fadeIn 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards",
        "slide-up": "slideUp 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards",
      },
      keyframes: {
        fadeIn: {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        slideUp: {
          "0%": { transform: "translateY(20px)", opacity: "0" },
          "100%": { transform: "translateY(0)", opacity: "1" },
        },
      },
    },
  },
  plugins: [],
};

export default config;
