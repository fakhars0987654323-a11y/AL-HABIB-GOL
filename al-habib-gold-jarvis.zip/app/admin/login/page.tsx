"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import { Lock } from "lucide-react";
import { useRouter } from "next/navigation";

export default function AdminLoginPage() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data?.error || "Login failed.");
        return;
      }

      router.push("/admin/dashboard");
      router.refresh();
    } catch {
      setError("Connection issue — please try again.");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <main className="min-h-screen bg-background flex items-center justify-center px-6">
      <motion.form
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        onSubmit={handleSubmit}
        className="w-full max-w-sm bg-surface border border-neutral-800 p-8 space-y-6"
      >
        <div className="flex flex-col items-center space-y-2 text-center">
          <div className="p-3 border border-gold rounded-full">
            <Lock className="w-5 h-5 text-gold" />
          </div>
          <h1 className="font-serif text-2xl text-neutral-100">Owner Access</h1>
          <p className="text-xs uppercase tracking-widest text-neutral-500">
            Al Habib Gold — Admin
          </p>
        </div>

        <div className="space-y-2">
          <label htmlFor="password" className="text-xs uppercase tracking-wider text-neutral-400">
            Password
          </label>
          <input
            id="password"
            type="password"
            required
            autoFocus
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-background border border-neutral-800 focus:border-gold px-4 py-3 text-neutral-100 focus:outline-none transition-colors"
          />
        </div>

        {error && <p className="text-xs text-feedback-error">{error}</p>}

        <button
          type="submit"
          disabled={isSubmitting || !password}
          className="w-full bg-gold text-background py-3 uppercase tracking-[0.2em] text-xs font-medium hover:bg-gold-light disabled:opacity-40 disabled:cursor-not-allowed transition-colors duration-300"
        >
          {isSubmitting ? "Verifying…" : "Sign In"}
        </button>

        {/* PLACEHOLDER: 2FA input step goes here once TOTP enrollment exists.
            See lib/auth/admin-auth.ts for what's needed before enabling this. */}
      </motion.form>
    </main>
  );
}
