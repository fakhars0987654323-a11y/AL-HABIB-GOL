"use client";

import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, LogOut, ScrollText } from "lucide-react";
import { useRouter } from "next/navigation";

type ChatMessage = { role: "user" | "assistant"; content: string };
type AuditEntry = {
  id: string;
  timestamp: string;
  action: string;
  details?: Record<string, unknown>;
};

type CheckResult = {
  check: string;
  status: "ok" | "warning" | "error" | "not_configured";
  message: string;
};

type MonitorRun = {
  id: string;
  timestamp: string;
  results: CheckResult[];
  hasIssues: boolean;
};

export default function AdminDashboardPage() {
  const router = useRouter();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "assistant",
      content:
        "Owner assistant ready. Tell me what you'd like to change, review, or check — I'll always propose changes for your approval before anything goes live.",
    },
  ]);
  const [input, setInput] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [auditLog, setAuditLog] = useState<AuditEntry[]>([]);
  const [monitorRuns, setMonitorRuns] = useState<MonitorRun[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    refreshAuditLog();
    refreshMonitorStatus();
    const interval = setInterval(refreshMonitorStatus, 60_000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  async function refreshAuditLog() {
    try {
      const res = await fetch("/api/admin/audit-log");
      const data = await res.json();
      setAuditLog(data.entries || []);
    } catch {
      // non-fatal — log panel just stays stale until next refresh
    }
  }

  async function refreshMonitorStatus() {
    try {
      const res = await fetch("/api/admin/monitor-status");
      const data = await res.json();
      setMonitorRuns(data.runs || []);
    } catch {
      // non-fatal — panel just stays stale until next refresh
    }
  }

  async function sendMessage() {
    const trimmed = input.trim();
    if (!trimmed || isSending) return;

    const next: ChatMessage[] = [...messages, { role: "user", content: trimmed }];
    setMessages(next);
    setInput("");
    setIsSending(true);

    try {
      const res = await fetch("/api/chat/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: trimmed, history: next.slice(0, -1) }),
      });
      const data = await res.json();

      if (!res.ok) {
        setMessages((prev) => [...prev, { role: "assistant", content: data?.error || "Error." }]);
        return;
      }

      setMessages((prev) => [...prev, { role: "assistant", content: data.reply }]);
      refreshAuditLog();
    } finally {
      setIsSending(false);
    }
  }

  async function handleLogout() {
    await fetch("/api/admin/logout", { method: "POST" });
    router.push("/admin/login");
    router.refresh();
  }

  return (
    <main className="min-h-screen bg-background text-neutral-100 font-sans p-6 lg:p-10">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="flex justify-between items-center border-b border-neutral-800 pb-6">
          <div>
            <h1 className="font-serif text-2xl lg:text-3xl">Al Habib Gold — Owner Console</h1>
            <p className="text-xs uppercase tracking-widest text-gold pt-1">Private / Authenticated</p>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center space-x-2 border border-neutral-700 hover:border-gold px-4 py-2 text-xs uppercase tracking-widest transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Chat panel */}
          <div className="lg:col-span-2 bg-surface border border-neutral-800 flex flex-col h-[70vh]">
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-5 space-y-3">
              <AnimatePresence initial={false}>
                {messages.map((m, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`max-w-[85%] px-4 py-2 text-sm rounded-md whitespace-pre-wrap ${
                      m.role === "user"
                        ? "ml-auto bg-gold text-background"
                        : "mr-auto bg-background border border-neutral-800 text-neutral-200"
                    }`}
                  >
                    {m.content}
                  </motion.div>
                ))}
              </AnimatePresence>
              {isSending && (
                <div className="mr-auto flex space-x-1.5 px-4 py-2 bg-background border border-neutral-800 rounded-md w-fit">
                  {[0, 1, 2].map((d) => (
                    <motion.span
                      key={d}
                      className="w-1.5 h-1.5 rounded-full bg-gold"
                      animate={{ opacity: [0.3, 1, 0.3] }}
                      transition={{ duration: 1, repeat: Infinity, delay: d * 0.15 }}
                    />
                  ))}
                </div>
              )}
            </div>
            <div className="border-t border-neutral-800 p-3 flex items-center space-x-2">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage();
                  }
                }}
                placeholder="e.g. 'Update the making charges note on the homepage banner'"
                className="flex-1 bg-transparent text-sm placeholder-neutral-600 focus:outline-none"
              />
              <button
                onClick={sendMessage}
                disabled={isSending || !input.trim()}
                className="p-2 text-gold disabled:text-neutral-700"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Audit log panel */}
          <div className="bg-surface border border-neutral-800 p-5 space-y-4 h-[70vh] overflow-y-auto">
            <div className="flex items-center space-x-2 text-neutral-300">
              <ScrollText className="w-4 h-4 text-gold" />
              <h2 className="text-xs uppercase tracking-widest">Audit Log</h2>
            </div>
            {auditLog.length === 0 && (
              <p className="text-xs text-neutral-600">No actions recorded yet.</p>
            )}
            {auditLog.map((entry) => (
              <div key={entry.id} className="border-b border-neutral-800 pb-3 space-y-1">
                <p className="text-xs text-neutral-200">{entry.action}</p>
                <p className="text-[10px] text-neutral-500">
                  {new Date(entry.timestamp).toLocaleString()}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Site health panel */}
        <div className="bg-surface border border-neutral-800 p-5 space-y-4">
          <h2 className="text-xs uppercase tracking-widest text-neutral-300">Site Health Monitor</h2>
          {monitorRuns.length === 0 && (
            <p className="text-xs text-neutral-600">
              No monitor runs recorded yet. This fills in once your scheduler (Vercel Cron or an
              external cron service) starts calling /api/cron/monitor — see that file's comments
              for setup.
            </p>
          )}
          {monitorRuns[0] && (
            <div className="space-y-3">
              <p className="text-[10px] text-neutral-500">
                Last checked: {new Date(monitorRuns[0].timestamp).toLocaleString()}
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {monitorRuns[0].results.map((r, i) => (
                  <div
                    key={i}
                    className={`text-xs p-3 border rounded-md ${
                      r.status === "ok"
                        ? "border-feedback-success/40 text-feedback-success"
                        : r.status === "warning"
                        ? "border-feedback-warning/40 text-feedback-warning"
                        : r.status === "error"
                        ? "border-feedback-error/40 text-feedback-error"
                        : "border-neutral-800 text-neutral-500"
                    }`}
                  >
                    <p className="uppercase tracking-wider text-[10px] mb-1">{r.check}</p>
                    <p>{r.message}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <p className="text-xs text-neutral-600 max-w-2xl">
          Note: this dashboard currently logs conversation and login events. Actual
          content/price-change actions (with rollback) aren't wired to a real
          database yet — see the code comments in <code>lib/audit-log.ts</code> for
          what's needed before this reflects real site changes.
        </p>
      </div>
    </main>
  );
}
