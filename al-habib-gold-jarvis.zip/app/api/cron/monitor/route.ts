import { NextRequest, NextResponse } from "next/server";
import { runAllChecks } from "@/lib/monitoring/checks";
import { recordMonitorRun, dispatchAlert } from "@/lib/monitoring/store";

/**
 * This endpoint is meant to be called by a scheduler (Vercel Cron, or an
 * external service — see notes below), NOT by browsers or the public site.
 * It is intentionally outside the /admin path (so it doesn't require a
 * logged-in browser session) but is protected instead by a shared secret,
 * which only your scheduler knows.
 *
 * REQUIRED: set CRON_SECRET in your environment (any long random string).
 *
 * SCHEDULING NOTE: "every minute" needs a scheduler that supports 1-minute
 * intervals.
 *  - Vercel Cron on the Hobby (free) plan currently only supports
 *    once-per-day schedules — 1-minute intervals need Vercel Pro, or a free
 *    external scheduler like cron-job.org / GitHub Actions on a schedule,
 *    pointed at this URL with the secret header. I'm flagging this rather
 *    than assuming your plan supports it.
 */
export async function GET(req: NextRequest) {
  const providedSecret =
    req.headers.get("x-cron-secret") || req.nextUrl.searchParams.get("secret");

  if (!process.env.CRON_SECRET || providedSecret !== process.env.CRON_SECRET) {
    return NextResponse.json({ error: "Unauthorized." }, { status: 401 });
  }

  try {
    const results = await runAllChecks();
    const run = recordMonitorRun(results);
    await dispatchAlert(run);

    return NextResponse.json({
      timestamp: run.timestamp,
      hasIssues: run.hasIssues,
      results,
    });
  } catch (err) {
    console.error("Monitor run failed:", err);
    return NextResponse.json({ error: "Monitor run failed." }, { status: 500 });
  }
}
