import { NextRequest, NextResponse } from "next/server";
import { buildAdminSystemPrompt } from "@/lib/ai/admin-assistant-prompt";
import { logAdminAction } from "@/lib/audit-log";

// NOTE: this route is only reachable by an authenticated admin — enforced by
// middleware.ts, not by anything in this file. That's intentional: the
// isolation lives at the routing layer, not scattered per-handler.

const MAX_HISTORY_MESSAGES = 30;

function sanitizeMessage(raw: unknown): string | null {
  if (typeof raw !== "string") return null;
  const trimmed = raw.trim();
  if (!trimmed) return null;
  if (trimmed.length > 4000) return trimmed.slice(0, 4000);
  return trimmed.replace(/[\x00-\x09\x0B-\x1F\x7F]/g, "");
}

export async function POST(req: NextRequest) {
  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const message = sanitizeMessage(body?.message);
  if (!message) {
    return NextResponse.json({ error: "Message is required." }, { status: 400 });
  }

  const rawHistory = Array.isArray(body?.history) ? body.history : [];
  const history = rawHistory
    .slice(-MAX_HISTORY_MESSAGES)
    .filter((m: any) => m?.role === "user" || m?.role === "assistant")
    .map((m: any) => ({ role: m.role, content: sanitizeMessage(m.content) || "" }))
    .filter((m: any) => m.content);

  if (!process.env.ANTHROPIC_API_KEY) {
    return NextResponse.json(
      { error: "Server misconfiguration: ANTHROPIC_API_KEY is not set." },
      { status: 500 }
    );
  }

  logAdminAction({ action: "admin_chat_message", details: { messagePreview: message.slice(0, 200) } });

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6", // confirm current model string before launch
        max_tokens: 1200,
        system: buildAdminSystemPrompt(),
        messages: [...history, { role: "user", content: message }],
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error("Anthropic API error (admin chat):", response.status, errText);
      return NextResponse.json({ error: "Assistant temporarily unavailable." }, { status: 502 });
    }

    const data = await response.json();
    const reply = data.content
      ?.filter((block: any) => block.type === "text")
      .map((block: any) => block.text)
      .join("\n") || "";

    return NextResponse.json({ reply });
  } catch (err) {
    console.error("Admin chat handler error:", err);
    return NextResponse.json({ error: "Something went wrong." }, { status: 500 });
  }
}
