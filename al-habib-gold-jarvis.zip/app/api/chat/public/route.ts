import { NextRequest, NextResponse } from "next/server";
import {
  buildPublicSystemPrompt,
  getLiveRates,
  getProductCatalog,
} from "@/lib/ai/public-assistant-prompt";

// ---- Basic in-memory rate limiter (per IP) ----
// PLACEHOLDER: fine for a single-instance dev/staging deploy.
// For production on Vercel (multiple serverless instances), replace this
// with a shared store — e.g. Upstash Redis or Vercel KV — since in-memory
// state does not persist or share across instances/regions.
const RATE_LIMIT_WINDOW_MS = 60_000;
const RATE_LIMIT_MAX = 20;
const hits = new Map<string, { count: number; windowStart: number }>();

function isRateLimited(ip: string): boolean {
  const now = Date.now();
  const entry = hits.get(ip);
  if (!entry || now - entry.windowStart > RATE_LIMIT_WINDOW_MS) {
    hits.set(ip, { count: 1, windowStart: now });
    return false;
  }
  entry.count += 1;
  return entry.count > RATE_LIMIT_MAX;
}

// ---- Input sanitization ----
// Strips control characters and caps length. This is a chat message going
// to an LLM, not to a database or HTML renderer, so the main risks are
// prompt-injection attempts and abuse (huge payloads) rather than SQL/HTML
// injection — but we still never render model output as raw HTML client-side
// (see the widget: it's rendered as plain text), which closes the XSS angle.
function sanitizeMessage(raw: unknown): string | null {
  if (typeof raw !== "string") return null;
  const trimmed = raw.trim();
  if (!trimmed) return null;
  if (trimmed.length > 2000) return trimmed.slice(0, 2000);
  // Strip non-printable/control characters except newline
  return trimmed.replace(/[\x00-\x09\x0B-\x1F\x7F]/g, "");
}

const MAX_HISTORY_MESSAGES = 20;

export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";

  if (isRateLimited(ip)) {
    return NextResponse.json(
      { error: "Too many requests. Please wait a moment and try again." },
      { status: 429 }
    );
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const message = sanitizeMessage(body?.message);
  if (!message) {
    return NextResponse.json({ error: "Message is required." }, { status: 400 });
  }

  // History is customer-supplied conversational context only — never trusted
  // as a source of privileged instructions. It is capped and only ever used
  // as prior "user"/"assistant" turns, never as system content.
  const rawHistory = Array.isArray(body?.history) ? body.history : [];
  const history = rawHistory
    .slice(-MAX_HISTORY_MESSAGES)
    .filter((m: any) => m?.role === "user" || m?.role === "assistant")
    .map((m: any) => ({
      role: m.role,
      content: sanitizeMessage(m.content) || "",
    }))
    .filter((m: any) => m.content);

  if (!process.env.ANTHROPIC_API_KEY) {
    return NextResponse.json(
      { error: "Server misconfiguration: ANTHROPIC_API_KEY is not set." },
      { status: 500 }
    );
  }

  const [rates, catalogSample] = await Promise.all([
    getLiveRates(),
    getProductCatalog(),
  ]);

  const systemPrompt = buildPublicSystemPrompt({ rates, catalogSample });

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6", // NOTE: confirm this model string is current on your account before launch
        max_tokens: 800,
        system: systemPrompt,
        messages: [...history, { role: "user", content: message }],
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error("Anthropic API error (public chat):", response.status, errText);
      return NextResponse.json(
        { error: "The assistant is temporarily unavailable. Please try WhatsApp instead." },
        { status: 502 }
      );
    }

    const data = await response.json();
    const reply = data.content
      ?.filter((block: any) => block.type === "text")
      .map((block: any) => block.text)
      .join("\n") || "";

    return NextResponse.json({ reply });
  } catch (err) {
    console.error("Public chat handler error:", err);
    return NextResponse.json(
      { error: "Something went wrong. Please try again shortly." },
      { status: 500 }
    );
  }
}
