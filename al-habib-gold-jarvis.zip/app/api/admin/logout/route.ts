import { NextRequest, NextResponse } from "next/server";
import { SESSION_COOKIE_NAME } from "@/lib/auth/admin-auth";
import { logAdminAction } from "@/lib/audit-log";

export async function POST(_req: NextRequest) {
  logAdminAction({ action: "logout" });
  const res = NextResponse.json({ ok: true });
  res.cookies.set(SESSION_COOKIE_NAME, "", { maxAge: 0, path: "/" });
  return res;
}
