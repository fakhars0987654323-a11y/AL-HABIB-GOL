import { NextResponse } from "next/server";
import { getRecentRuns } from "@/lib/monitoring/store";

// Protected by middleware.ts (matches /api/admin/:path*) — only reachable
// with a valid admin session, same as the audit log endpoint.
export async function GET() {
  return NextResponse.json({ runs: getRecentRuns(20) });
}
