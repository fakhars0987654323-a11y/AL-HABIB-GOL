import { NextResponse } from "next/server";
import { getAuditLog } from "@/lib/audit-log";

export async function GET() {
  return NextResponse.json({ entries: getAuditLog() });
}
