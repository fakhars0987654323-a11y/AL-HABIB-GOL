import { NextRequest, NextResponse } from "next/server";
import {
  verifyPassword,
  createSessionToken,
  isLoginRateLimited,
  recordLoginAttempt,
  clearLoginAttempts,
  SESSION_COOKIE_NAME,
  SESSION_DURATION_SECONDS,
} from "@/lib/auth/admin-auth";
import { logAdminAction } from "@/lib/audit-log";

export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";

  if (isLoginRateLimited(ip)) {
    // Generic message — don't reveal whether it's the rate limit or bad
    // credentials, so an attacker can't distinguish account lockout state.
    return NextResponse.json(
      { error: "Too many attempts. Please try again later." },
      { status: 429 }
    );
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }

  const password = typeof body?.password === "string" ? body.password : "";
  if (!password) {
    return NextResponse.json({ error: "Password is required." }, { status: 400 });
  }

  let isValid = false;
  try {
    isValid = await verifyPassword(password);
  } catch (err) {
    console.error("Admin login config error:", err);
    return NextResponse.json(
      { error: "Server misconfiguration. Contact the developer." },
      { status: 500 }
    );
  }

  if (!isValid) {
    recordLoginAttempt(ip);
    logAdminAction({ action: "login_failed", details: { ip } });
    return NextResponse.json({ error: "Invalid password." }, { status: 401 });
  }

  clearLoginAttempts(ip);
  const token = await createSessionToken();
  logAdminAction({ action: "login_success", details: { ip } });

  const res = NextResponse.json({ ok: true });
  res.cookies.set(SESSION_COOKIE_NAME, token, {
    httpOnly: true, // never accessible to client-side JS — mitigates XSS token theft
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict", // mitigates CSRF
    maxAge: SESSION_DURATION_SECONDS,
    path: "/",
  });
  return res;
}
