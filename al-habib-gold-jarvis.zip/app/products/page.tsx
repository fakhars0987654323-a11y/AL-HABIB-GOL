import { getProducts, getCategories } from "@/lib/products/catalog";
import { ProductGallery } from "@/components/gallery/ProductGallery";

export default async function ProductsPage() {
  const [products, categories] = await Promise.all([getProducts(), getCategories()]);

  return (
    <main className="min-h-screen bg-background text-neutral-100 font-sans px-6 py-12">
      <div className="max-w-6xl mx-auto space-y-8">
        <h1 className="font-serif text-3xl">Our Collection</h1>
        <ProductGallery products={products} categories={categories} />
      </div>
    </main>
  );
}
