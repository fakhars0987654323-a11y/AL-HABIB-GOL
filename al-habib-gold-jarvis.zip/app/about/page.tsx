import { ABOUT_SECTIONS } from "@/lib/legal/content";
import { BUSINESS_INFO } from "@/lib/ai/public-assistant-prompt";

function Section({ title, content }: { title: string; content: string | null }) {
  return (
    <div className="space-y-2 border-b border-neutral-800 pb-6">
      <h2 className="font-serif text-xl text-gold">{title}</h2>
      <p className="text-sm text-neutral-400">
        {content ?? "Content coming soon — add this from the admin dashboard."}
      </p>
    </div>
  );
}

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-background text-neutral-100 font-sans px-6 py-12">
      <div className="max-w-3xl mx-auto space-y-8">
        <div className="space-y-2">
          <h1 className="font-serif text-3xl">About {BUSINESS_INFO.name}</h1>
          <p className="text-sm text-neutral-500">{BUSINESS_INFO.address}</p>
        </div>

        {/* Photo placeholders: deliberately not fabricated stock photos of
            "your father" or "you" — that would misrepresent real people.
            Upload real photos via the admin media manager once it exists. */}
        <div className="grid grid-cols-2 gap-4">
          <div className="aspect-square bg-surface border border-neutral-800 flex items-center justify-center text-xs text-neutral-600 uppercase tracking-widest">
            Founder photo — add via admin
          </div>
          <div className="aspect-square bg-surface border border-neutral-800 flex items-center justify-center text-xs text-neutral-600 uppercase tracking-widest">
            Your photo — add via admin
          </div>
        </div>

        <Section title="Our Story" content={ABOUT_SECTIONS.companyStory} />
        <Section title="Shop History" content={ABOUT_SECTIONS.shopHistory} />
        <Section title="Mission" content={ABOUT_SECTIONS.mission} />
        <Section title="Vision" content={ABOUT_SECTIONS.vision} />

        <div className="space-y-2">
          <h2 className="font-serif text-xl text-gold">Certifications</h2>
          {ABOUT_SECTIONS.certifications.length === 0 ? (
            <p className="text-sm text-neutral-400">
              List your hallmark and business registration certifications here once provided.
            </p>
          ) : (
            <ul className="text-sm text-neutral-300 list-disc list-inside">
              {ABOUT_SECTIONS.certifications.map((c) => (
                <li key={c}>{c}</li>
              ))}
            </ul>
          )}
        </div>

        <div className="space-y-1 text-sm text-neutral-400">
          <p className="text-gold text-xs uppercase tracking-widest">Contact</p>
          <p>{BUSINESS_INFO.phones.join(" · ")}</p>
        </div>
      </div>
    </main>
  );
}
