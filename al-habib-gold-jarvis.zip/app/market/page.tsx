import { RateDisplay } from "@/components/market/RateDisplay";
import { RateCalculator } from "@/components/market/RateCalculator";

export default function MarketPage() {
  return (
    <main className="min-h-screen bg-background text-neutral-100 font-sans px-6 py-12">
      <div className="max-w-6xl mx-auto space-y-12">
        <RateDisplay />
        <RateCalculator />
      </div>
    </main>
  );
}
