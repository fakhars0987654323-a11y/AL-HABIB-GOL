import { LegalPlaceholderPage } from "@/components/legal/LegalPlaceholderPage";
import { LEGAL_SECTION_HEADINGS } from "@/lib/legal/content";

export default function RefundPolicyPage() {
  return (
    <LegalPlaceholderPage
      title="Refund & Exchange Policy"
      sections={LEGAL_SECTION_HEADINGS["refund-policy"]}
    />
  );
}
