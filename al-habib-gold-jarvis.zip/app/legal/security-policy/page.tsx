import { SECURITY_POLICY } from "@/lib/legal/content";

export default function SecurityPolicyPage() {
  return (
    <main className="min-h-screen bg-background text-neutral-100 font-sans px-6 py-12">
      <div className="max-w-3xl mx-auto space-y-6">
        <h1 className="font-serif text-3xl">🔒 Website Security & Acceptable Use Policy</h1>
        <div className="text-sm text-neutral-300 whitespace-pre-line leading-relaxed">
          {SECURITY_POLICY}
        </div>
      </div>
    </main>
  );
}
