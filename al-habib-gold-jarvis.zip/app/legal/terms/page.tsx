import { LegalPlaceholderPage } from "@/components/legal/LegalPlaceholderPage";
import { LEGAL_SECTION_HEADINGS } from "@/lib/legal/content";

export default function TermsPage() {
  return (
    <LegalPlaceholderPage
      title="Terms & Conditions"
      sections={LEGAL_SECTION_HEADINGS["terms-and-conditions"]}
    />
  );
}
