import { LegalPlaceholderPage } from "@/components/legal/LegalPlaceholderPage";
import { LEGAL_SECTION_HEADINGS } from "@/lib/legal/content";

export default function PrivacyPolicyPage() {
  return (
    <LegalPlaceholderPage
      title="Privacy Policy"
      sections={LEGAL_SECTION_HEADINGS["privacy-policy"]}
    />
  );
}
