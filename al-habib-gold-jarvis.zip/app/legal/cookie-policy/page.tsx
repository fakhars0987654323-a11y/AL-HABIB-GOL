import { LegalPlaceholderPage } from "@/components/legal/LegalPlaceholderPage";
import { LEGAL_SECTION_HEADINGS } from "@/lib/legal/content";

export default function CookiePolicyPage() {
  return (
    <LegalPlaceholderPage
      title="Cookie Policy"
      sections={LEGAL_SECTION_HEADINGS["cookie-policy"]}
    />
  );
}
