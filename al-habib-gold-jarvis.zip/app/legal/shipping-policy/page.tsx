import { LegalPlaceholderPage } from "@/components/legal/LegalPlaceholderPage";
import { LEGAL_SECTION_HEADINGS } from "@/lib/legal/content";

export default function ShippingPolicyPage() {
  return (
    <LegalPlaceholderPage
      title="Shipping & Delivery Policy"
      sections={LEGAL_SECTION_HEADINGS["shipping-policy"]}
    />
  );
}
